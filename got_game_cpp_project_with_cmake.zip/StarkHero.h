#ifndef STARKHERO_H
#define STARKHERO_H
#include "Hero.h"

class StarkHero : public Hero {
public:
    std::string getName() const override {
        return "Jon Snow";
    }

    std::string getWeapon() const override {
        return "Longclaw (Valyrian steel sword)";
    }
};
#endif
