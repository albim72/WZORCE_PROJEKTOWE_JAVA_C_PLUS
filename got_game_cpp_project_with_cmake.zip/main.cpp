#include "GameWorldBuilder.h"
#include "StarkFactory.h"
// #include "LannisterFactory.h"

int main() {
    const KingdomFactory* factory = new StarkFactory(); // Można zmienić na LannisterFactory
    GameWorldBuilder builder(factory);
    GameWorld game = builder.buildWorld();

    std::cout << "=== Świat gry ===" << std::endl;
    game.displayWorld();

    delete factory;
    return 0;
}
