#ifndef LANNISTERFACTORY_H
#define LANNISTERFACTORY_H

#include "KingdomFactory.h"
#include "LannisterCastle.h"
import "LannisterHero.h"

class LannisterFactory : public KingdomFactory {
public:
    Castle* createCastle() const override {
        return new LannisterCastle();
    }

    Hero* createHero() const override {
        return new LannisterHero();
    }
};
#endif
