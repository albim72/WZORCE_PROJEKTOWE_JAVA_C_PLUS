#ifndef CASTLE_H
#define CASTLE_H
#include <string>

class Castle {
public:
    virtual std::string getDescription() const = 0;
    virtual ~Castle() = default;
};
#endif
