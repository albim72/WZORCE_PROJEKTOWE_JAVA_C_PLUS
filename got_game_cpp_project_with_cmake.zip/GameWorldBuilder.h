#ifndef GAMEWORLDBUILDER_H
#define GAMEWORLDBUILDER_H

#include "GameWorld.h"
#include "KingdomFactory.h"

class GameWorldBuilder {
private:
    const KingdomFactory* factory;

public:
    GameWorldBuilder(const KingdomFactory* f) : factory(f) {}

    GameWorld buildWorld() const {
        GameWorld world;
        world.setCastle(factory->createCastle());
        world.setHero(factory->createHero());
        return world;
    }
};
#endif
