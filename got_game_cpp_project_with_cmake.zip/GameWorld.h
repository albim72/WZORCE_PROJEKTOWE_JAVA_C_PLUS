#ifndef GAMEWORLD_H
#define GAMEWORLD_H

#include "Castle.h"
#include "Hero.h"
#include <iostream>

class GameWorld {
private:
    Castle* castle;
    Hero* hero;

public:
    GameWorld() : castle(nullptr), hero(nullptr) {}
    ~GameWorld() {
        delete castle;
        delete hero;
    }

    void setCastle(Castle* c) { castle = c; }
    void setHero(Hero* h) { hero = h; }

    void displayWorld() const {
        std::cout << "Zamek: " << castle->getDescription() << std::endl;
        std::cout << "Bohater: " << hero->getName()
                  << ", Broń: " << hero->getWeapon() << std::endl;
    }
};
#endif
