#ifndef LANNISTERCASTLE_H
#define LANNISTERCASTLE_H
#include "Castle.h"

class LannisterCastle : public Castle {
public:
    std::string getDescription() const override {
        return "Casterly Rock - twierdza rodu Lannister";
    }
};
#endif
