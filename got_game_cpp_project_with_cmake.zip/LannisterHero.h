#ifndef LANNISTERHERO_H
#define LANNISTERHERO_H
#include "Hero.h"

class LannisterHero : public Hero {
public:
    std::string getName() const override {
        return "Jaime Lannister";
    }

    std::string getWeapon() const override {
        return "Sword of the Kingsguard";
    }
};
#endif
