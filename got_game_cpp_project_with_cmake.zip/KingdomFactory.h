#ifndef KINGDOMFACTORY_H
#define KINGDOMFACTORY_H

#include "Castle.h"
#include "Hero.h"

class KingdomFactory {
public:
    virtual Castle* createCastle() const = 0;
    virtual Hero* createHero() const = 0;
    virtual ~KingdomFactory() = default;
};
#endif
