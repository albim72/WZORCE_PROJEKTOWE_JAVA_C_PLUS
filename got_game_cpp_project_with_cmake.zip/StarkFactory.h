#ifndef STARKFACTORY_H
#define STARKFACTORY_H

#include "KingdomFactory.h"
#include "StarkCastle.h"
#include "StarkHero.h"

class StarkFactory : public KingdomFactory {
public:
    Castle* createCastle() const override {
        return new StarkCastle();
    }

    Hero* createHero() const override {
        return new StarkHero();
    }
};
#endif
