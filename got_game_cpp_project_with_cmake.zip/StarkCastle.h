#ifndef STARKCASTLE_H
#define STARKCASTLE_H
#include "Castle.h"

class StarkCastle : public Castle {
public:
    std::string getDescription() const override {
        return "Winterfell - twierdza rodu Stark";
    }
};
#endif
