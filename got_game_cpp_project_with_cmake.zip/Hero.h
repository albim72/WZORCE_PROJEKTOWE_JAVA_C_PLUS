#ifndef HERO_H
#define HERO_H
#include <string>

class Hero {
public:
    virtual std::string getName() const = 0;
    virtual std::string getWeapon() const = 0;
    virtual ~Hero() = default;
};
#endif
