package model;
public class AggressiveStrategy implements Strategy {
    public String execute() {
        return "Bohater atakuje agresywnie!";
    }
}
