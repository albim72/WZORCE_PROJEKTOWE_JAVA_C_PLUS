package model;

public class StarkCastle implements Castle {
    public String getDescription() {
        return "Winterfell - twierdza rodu Stark";
    }
}
