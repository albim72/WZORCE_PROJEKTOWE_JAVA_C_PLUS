package model;
public interface Strategy {
    String execute();
}
