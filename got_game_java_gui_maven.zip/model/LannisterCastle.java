package model;

public class LannisterCastle implements Castle {
    public String getDescription() {
        return "Casterly Rock - twierdza rodu Lannister";
    }
}
