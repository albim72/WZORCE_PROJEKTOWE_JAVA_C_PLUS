package model;
public class DefensiveStrategy implements Strategy {
    public String execute() {
        return "Bohater broni się ostrożnie.";
    }
}
