package model;

public interface Castle {
    String getDescription();
}
