package model;

public interface Hero {
    String getName();
    String getWeapon();
}
