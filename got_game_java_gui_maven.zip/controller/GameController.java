package controller;

import factory.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.*;
import model.AggressiveStrategy;
import model.DefensiveStrategy;

public class GameController {
    @FXML private ComboBox<String> factionCombo;
    @FXML private ComboBox<String> strategyCombo;
    @FXML private TextArea resultArea;

    @FXML
    public void initialize() {
        factionCombo.getItems().addAll("Stark", "Lannister");
        strategyCombo.getItems().addAll("Agresywna", "Defensywna");
    }

    @FXML
    public void onStartGame() {
        KingdomFactory factory;
        String choice = factionCombo.getValue();
        if ("Lannister".equals(choice)) {
            factory = new LannisterFactory();
        } else {
            factory = new StarkFactory();
        }

        Castle castle = factory.createCastle();
        Hero hero = factory.createHero();

        Strategy strategy = "Defensywna".equals(strategyCombo.getValue()) 
                            ? new DefensiveStrategy() 
                            : new AggressiveStrategy();

        String output = "Zamek: " + castle.getDescription() + "\n"
                      + "Bohater: " + hero.getName() + "\n"
                      + "Broń: " + hero.getWeapon() + "\n"
                      + "Styl walki: " + strategy.execute();

        resultArea.setText(output);
    }
}
