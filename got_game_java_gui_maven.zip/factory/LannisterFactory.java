package factory;

import model.*;

public class LannisterFactory implements KingdomFactory {
    public Castle createCastle() { return new LannisterCastle(); }
    public Hero createHero() { return new LannisterHero(); }
}
