package factory;

import model.Castle;
import model.Hero;

public interface KingdomFactory {
    Castle createCastle();
    Hero createHero();
}
