public class GameWorld {
    private Castle castle;
    private Hero hero;

    public void setCastle(Castle castle) {
        this.castle = castle;
    }
    public void setHero(Hero hero) {
        this.hero = hero;
    }

    public Hero getHero() {
        return hero;
    }

    public String getWorldInfo() {
        return "Zamek: " + castle.getDescription() + "\nBohater: " + hero.getName() + ", Broń: " + hero.getWeapon();
    }
}
