public class ArmoredHero extends HeroDecorator {
    public ArmoredHero(Hero hero) {
        super(hero);
    }

    public String getWeapon() {
        return decoratedHero.getWeapon() + " + stalowy pancerz";
    }
}
