import factory.*;
import facade.*;
import view.*;
import controller.*;
import decorator.*;
import behavioral.*;

public class GameLauncher {
    public static void main(String[] args) {
        KingdomFactory factory = new StarkFactory();
        GameFacade facade = new GameFacade(factory);
        GameWorld world = facade.createGameWorld();

        world.setHero(new ArmoredHero(world.getHero()));
        GameView view = new ConsoleGameView();
        GamePresenter presenter = new GamePresenter(world, view);
        presenter.updateView();

        Context context = new Context();
        context.setStrategy(new AggressiveStrategy());
        context.executeStrategy();
    }
}
