package facade;
import factory.KingdomFactory;
public class GameFacade {
    private GameWorldBuilder builder;
    public GameFacade(KingdomFactory factory) { this.builder = new GameWorldBuilder(factory); }
    public GameWorld createGameWorld() { return builder.buildWorld(); }
}
