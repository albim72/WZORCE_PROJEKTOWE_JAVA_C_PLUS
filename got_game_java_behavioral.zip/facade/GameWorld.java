package facade;
import model.Castle;
import model.Hero;
public class GameWorld {
    private Castle castle;
    private Hero hero;
    public void setCastle(Castle c) { this.castle = c; }
    public void setHero(Hero h) { this.hero = h; }
    public Hero getHero() { return hero; }
    public String getWorldInfo() {
        return "Zamek: " + castle.getDescription() + "\nBohater: " + hero.getName() + ", Broń: " + hero.getWeapon();
    }
}
