package controller;
import view.GameView;
import facade.GameWorld;
public class GamePresenter {
    private GameWorld model;
    private GameView view;
    public GamePresenter(GameWorld model, GameView view) {
        this.model = model;
        this.view = view;
    }
    public void updateView() {
        view.display(model.getWorldInfo());
    }
}
