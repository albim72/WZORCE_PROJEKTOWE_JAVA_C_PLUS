package factory;
import model.*;
public interface KingdomFactory {
    Castle createCastle();
    Hero createHero();
}
