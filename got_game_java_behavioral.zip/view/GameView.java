package view;
public interface GameView {
    void display(String content);
}
