package view;
public class ConsoleGameView implements GameView {
    public void display(String content) {
        System.out.println("=== Świat gry ===\n" + content);
    }
}
