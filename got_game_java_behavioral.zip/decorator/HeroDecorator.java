package decorator;
import model.Hero;
public abstract class HeroDecorator implements Hero {
    protected Hero decoratedHero;
    public HeroDecorator(Hero hero) { this.decoratedHero = hero; }
    public String getName() { return decoratedHero.getName(); }
    public String getWeapon() { return decoratedHero.getWeapon(); }
}
