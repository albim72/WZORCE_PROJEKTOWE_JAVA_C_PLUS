package model;
public class LannisterHero implements Hero {
    public String getName() { return "Jaime Lannister"; }
    public String getWeapon() { return "Sword of the Kingsguard"; }
}
