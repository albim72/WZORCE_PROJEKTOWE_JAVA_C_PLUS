package behavioral;
public class DefensiveStrategy implements Strategy {
    public void execute() {
        System.out.println("Bohater broni się ostrożnie.");
    }
}
