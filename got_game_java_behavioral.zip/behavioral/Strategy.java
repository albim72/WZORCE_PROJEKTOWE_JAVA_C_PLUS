package behavioral;
public interface Strategy {
    void execute();
}
