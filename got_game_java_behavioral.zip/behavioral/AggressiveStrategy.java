package behavioral;
public class AggressiveStrategy implements Strategy {
    public void execute() {
        System.out.println("Bohater atakuje agresywnie!");
    }
}
