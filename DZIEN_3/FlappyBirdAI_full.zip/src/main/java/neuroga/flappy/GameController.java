package neuroga.flappy;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import neuroga.flappy.core.Bird;
import neuroga.flappy.core.Pipe;
import neuroga.flappy.core.GeneticTrainer;

import java.util.*;
import java.util.function.BiConsumer;

public class GameController {
    public static final double WIDTH = 600, HEIGHT = 400;
    public static final double GRAVITY = 0.5;
    public static final double JUMP_STRENGTH = 8;
    private Canvas canvas;
    private GraphicsContext gc;
    private List<BiConsumer<Integer, Bird>> observers = new ArrayList<>();
    private List<Bird> birds;
    private List<Pipe> pipes;
    private GeneticTrainer trainer;
    private int generation = 0;
    private boolean running = false;

    public GameController() {
        canvas = new Canvas(WIDTH, HEIGHT);
        gc = canvas.getGraphicsContext2D();
        trainer = new GeneticTrainer();
        initGame();
    }

    public Canvas getCanvas() { return canvas; }
    public void addObserver(BiConsumer<Integer, Bird> obs) { observers.add(obs); }

    public void start() {
        running = true;
        new AnimationTimer() {
            private long lastTime = 0;
            @Override
            public void handle(long now) {
                if (!running) return;
                if (lastTime > 0) {
                    double delta = (now - lastTime) / 1e9;
                    update(delta);
                    render();
                }
                lastTime = now;
            }
        }.start();
    }

    public void pause() { running = false; }

    public void reset() {
        running = false;
        generation = 0;
        trainer.reset();
        initGame();
        render();
    }

    public void setPopulationSize(int size) { trainer.setPopulationSize(size); }
    public int getPopulationSize() { return trainer.getPopulationSize(); }
    public void setMutationRate(double rate) { trainer.setMutationRate(rate); }
    public double getMutationRate() { return trainer.getMutationRate(); }

    private void initGame() {
        birds = trainer.initializePopulation();
        pipes = new ArrayList<>();
        pipes.add(new Pipe(WIDTH, HEIGHT));
    }

    private void update(double delta) {
        pipes.forEach(p -> p.update(delta));
        birds.forEach(b -> {
            if (b.isAlive()) b.update(pipes);
        });
        boolean anyAlive = birds.stream().anyMatch(Bird::isAlive);
        if (!anyAlive) evolve();
    }

    private void evolve() {
        generation++;
        List<double[]> genomes = new ArrayList<>();
        List<Double> fitnesses = new ArrayList<>();
        for (Bird b : birds) {
            genomes.add(b.getGenome());
            fitnesses.add(b.getFitness());
        }
        List<double[]> nextGen = trainer.evolve(genomes, fitnesses);
        birds.clear();
        for (double[] g : nextGen) {
            birds.add(new Bird(g, trainer.getPrototypeNetwork()));
        }
        pipes.clear();
        pipes.add(new Pipe(WIDTH, HEIGHT));
        notifyObservers();
    }

    private void notifyObservers() {
        Bird best = birds.stream().max(Comparator.comparingDouble(Bird::getFitness)).get();
        for (BiConsumer<Integer, Bird> obs : observers) {
            obs.accept(generation, best);
        }
    }

    private void render() {
        gc.setFill(Color.SKYBLUE);
        gc.fillRect(0, 0, WIDTH, HEIGHT);
        pipes.forEach(p -> p.render(gc));
        birds.forEach(b -> b.render(gc));
    }
}