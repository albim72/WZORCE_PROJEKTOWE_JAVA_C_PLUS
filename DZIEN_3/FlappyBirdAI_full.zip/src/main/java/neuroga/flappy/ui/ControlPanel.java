package neuroga.flappy.ui;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;
import neuroga.flappy.GameController;

public class ControlPanel extends VBox {
    public ControlPanel(GameController controller) {
        setSpacing(10);
        setPadding(new Insets(10));

        Button startBtn = new Button("Start");
        Button pauseBtn = new Button("Pause");
        Button resetBtn = new Button("Reset");

        Slider popSlider = new Slider(10, 200, controller.getPopulationSize());
        popSlider.setShowTickLabels(true);
        popSlider.setShowTickMarks(true);
        popSlider.valueProperty().addListener((obs, o, n) -> controller.setPopulationSize(n.intValue()));

        Slider mutSlider = new Slider(0, 1, controller.getMutationRate());
        mutSlider.setShowTickLabels(true);
        mutSlider.setShowTickMarks(true);
        mutSlider.valueProperty().addListener((obs, o, n) -> controller.setMutationRate(n.doubleValue()));

        startBtn.setOnAction(e -> controller.start());
        pauseBtn.setOnAction(e -> controller.pause());
        resetBtn.setOnAction(e -> controller.reset());

        getChildren().addAll(startBtn, pauseBtn, resetBtn, popSlider, mutSlider);
    }
}