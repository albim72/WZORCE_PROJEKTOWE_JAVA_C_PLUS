package neuroga.flappy.ui;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import neuroga.flappy.GameController;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        GameController controller = new GameController();
        ControlPanel controlPanel = new ControlPanel(controller);
        FitnessChart fitnessChart = new FitnessChart();

        controller.addObserver((gen, best) -> fitnessChart.addData(gen, best.getFitness()));

        BorderPane root = new BorderPane();
        root.setCenter(controller.getCanvas());
        root.setRight(controlPanel);
        root.setBottom(fitnessChart.getChart());

        Scene scene = new Scene(root, GameController.WIDTH + 250, GameController.HEIGHT + 150);
        primaryStage.setTitle("Flappy Bird AI Trainer");
        primaryStage.setScene(scene);
        primaryStage.show();

        controller.start();
    }

    public static void main(String[] args) {
        launch(args);
    }
}