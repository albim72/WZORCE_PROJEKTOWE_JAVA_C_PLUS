package neuroga.flappy.ui;

import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

public class FitnessChart {
    private LineChart<Number, Number> chart;
    private XYChart.Series<Number, Number> bestSeries;

    public FitnessChart() {
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("Generation");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Best Fitness");

        chart = new LineChart<>(xAxis, yAxis);
        chart.setTitle("Fitness Over Generations");

        bestSeries = new XYChart.Series<>();
        bestSeries.setName("Best Fitness");
        chart.getData().add(bestSeries);
    }

    public LineChart<Number, Number> getChart() {
        return chart;
    }

    public void addData(int generation, double fitness) {
        bestSeries.getData().add(new XYChart.Data<>(generation, fitness));
    }
}