package neuroga.flappy.core;

public class NeuralNetworkFactory {
    public static NeuralNetwork createDefaultXORNetwork() {
        return new NeuralNetworkBuilder().withLayers(3, 5, 1).build();
    }
}