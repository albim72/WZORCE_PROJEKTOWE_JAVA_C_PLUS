package neuroga.flappy.core;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import java.util.Random;

public class Pipe {
    private double x, gapY;
    private static final double WIDTH = 50, GAP = 120;
    private double speed = 2;

    public Pipe(double startX, double maxY) {
        this.x = startX;
        this.gapY = GAP + new Random().nextDouble() * (maxY - 2 * GAP);
    }

    public void update(double delta) {
        x -= speed;
        if (x < -WIDTH) {
            x += GameController.WIDTH + WIDTH;
            gapY = GAP + new Random().nextDouble() * (GameController.HEIGHT - 2 * GAP);
        }
    }

    public void render(GraphicsContext gc) {
        gc.setFill(Color.GREEN);
        gc.fillRect(x, 0, WIDTH, gapY - GAP / 2);
        gc.fillRect(x, gapY + GAP / 2, WIDTH, GameController.HEIGHT - gapY - GAP / 2);
    }

    public double getX() { return x; }
    public double getGapY() { return gapY; }

    public boolean collides(double bx, double by) {
        return (bx > x && bx < x + WIDTH) &&
               (by < gapY - GAP / 2 || by > gapY + GAP / 2);
    }
}