package neuroga.flappy.core;

import java.util.Arrays;

public class NeuralNetwork {
    private int[] layers;
    private int genomeLength;

    public NeuralNetwork(int... layers) {
        this.layers = layers;
        this.genomeLength = calculateGenomeLength(layers);
    }

    private int calculateGenomeLength(int[] layers) {
        int len = 0;
        for (int i = 0; i < layers.length - 1; i++) {
            len += layers[i] * layers[i+1] + layers[i+1];
        }
        return len;
    }

    public int getGenomeLength() { return genomeLength; }

    public double[] forward(double[] genome, double[] input) {
        double[] activations = Arrays.copyOf(input, input.length);
        int offset = 0;
        for (int l = 0; l < layers.length - 1; l++) {
            int in = layers[l], out = layers[l+1];
            double[] next = new double[out];
            for (int i = 0; i < in; i++)
                for (int j = 0; j < out; j++)
                    next[j] += genome[offset + i * out + j] * activations[i];
            offset += in*out;
            for (int j = 0; j < out; j++) next[j] += genome[offset + j];
            offset += out;
            for (int j = 0; j < out; j++) next[j] = 1.0 / (1.0 + Math.exp(-next[j]));
            activations = next;
        }
        return activations;
    }
}