package neuroga.flappy.core;

import java.util.List;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Bird {
    private double x = 100, y, velocity = 0;
    private double[] genome;
    private NeuralNetwork nn;
    private boolean alive = true;
    private double fitness = 0;

    public Bird(double[] genome, NeuralNetwork prototype) {
        this.genome = genome;
        this.nn = prototype;
        this.y = GameController.HEIGHT / 2;
    }

    public void update(List<Pipe> pipes) {
        if (!alive) return;
        Pipe p = pipes.get(0);
        double dx = p.getX() - x;
        double dy = (p.getGapY() - y);
        double[] inputs = { dx / GameController.WIDTH, dy / GameController.HEIGHT, velocity / 10 };
        double[] out = nn.forward(genome, inputs);
        if (out[0] > 0.5) velocity = -GameController.JUMP_STRENGTH;
        velocity += GameController.GRAVITY;
        y += velocity;
        if (y < 0 || y > GameController.HEIGHT || p.collides(x, y)) {
            alive = false;
        } else {
            fitness += 1;
        }
    }

    public void render(GraphicsContext gc) {
        gc.setFill(alive ? Color.YELLOW : Color.GRAY);
        gc.fillOval(x - 10, y - 10, 20, 20);
    }

    public boolean isAlive() { return alive; }
    public double getFitness() { return fitness; }
    public double[] getGenome() { return genome; }
}