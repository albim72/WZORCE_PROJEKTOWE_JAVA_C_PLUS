package neuroga.flappy.core;

public class NeuralNetworkBuilder {
    private int[] layers;
    public NeuralNetworkBuilder withLayers(int... layers) {
        this.layers = layers;
        return this;
    }
    public NeuralNetwork build() {
        return new NeuralNetwork(layers);
    }
}