package neuroga.flappy.core;

import java.util.*;

public class GeneticTrainer {
    private NeuralNetwork prototype;
    private int populationSize = 50;
    private double mutationRate = 0.1;
    private Random rand = new Random();

    public GeneticTrainer() {
        prototype = NeuralNetworkFactory.createDefaultXORNetwork();
    }

    public void setPopulationSize(int size) { this.populationSize = size; }
    public int getPopulationSize() { return populationSize; }
    public void setMutationRate(double rate) { this.mutationRate = rate; }
    public double getMutationRate() { return mutationRate; }

    public void reset() {
        // no action needed for stateless trainer
    }

    public List<Bird> initializePopulation() {
        List<Bird> birds = new ArrayList<>();
        int len = prototype.getGenomeLength();
        for (int i = 0; i < populationSize; i++) {
            double[] genome = new double[len];
            for (int j = 0; j < len; j++)
                genome[j] = rand.nextDouble() * 2 - 1;
            birds.add(new Bird(genome, prototype));
        }
        return birds;
    }

    public List<double[]> evolve(List<double[]> genomes, List<Double> fitnesses) {
        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < genomes.size(); i++) indices.add(i);
        List<double[]> nextGen = new ArrayList<>();
        // elitism
        int best = fitnesses.indexOf(Collections.max(fitnesses));
        nextGen.add(genomes.get(best));
        // rest
        while (nextGen.size() < populationSize) {
            int a = rand.nextInt(genomes.size()), b = rand.nextInt(genomes.size());
            int winner1 = fitnesses.get(a) > fitnesses.get(b) ? a : b;
            a = rand.nextInt(genomes.size()); b = rand.nextInt(genomes.size());
            int winner2 = fitnesses.get(a) > fitnesses.get(b) ? a : b;
            double[] p1 = genomes.get(winner1), p2 = genomes.get(winner2);
            double[] child = new double[p1.length];
            for (int i = 0; i < child.length; i++)
                child[i] = rand.nextBoolean() ? p1[i] : p2[i];
            for (int i = 0; i < child.length; i++)
                if (rand.nextDouble() < mutationRate)
                    child[i] += rand.nextGaussian() * 0.3;
            nextGen.add(child);
        }
        return nextGen;
    }

    public NeuralNetwork getPrototypeNetwork() {
        return prototype;
    }
}