package main;

import chain.*;

public class DocumentApprovalSystem {
    public static void main(String[] args) {
        Approver teamLeader = new TeamLeader();
        Approver departmentManager = new DepartmentManager();
        Approver ceo = new CEO();

        teamLeader.setNextApprover(departmentManager);
        departmentManager.setNextApprover(ceo);

        Document doc1 = new Document("Plan Szkolenia", 1);
        Document doc2 = new Document("Budżet Projektu", 2);
        Document doc3 = new Document("Fuzja Firm", 3);

        teamLeader.approveRequest(doc1);
        teamLeader.approveRequest(doc2);
        teamLeader.approveRequest(doc3);
    }
}
