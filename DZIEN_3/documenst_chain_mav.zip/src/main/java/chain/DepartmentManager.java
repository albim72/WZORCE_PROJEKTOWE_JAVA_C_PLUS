package chain;

public class DepartmentManager extends Approver {
    public void approveRequest(Document doc) {
        if (doc.getSensitivityLevel() <= 2) {
            System.out.println("Kierownik Działu zatwierdził dostęp do dokumentu: " + doc.getTitle());
        } else if (nextApprover != null) {
            nextApprover.approveRequest(doc);
        }
    }
}
