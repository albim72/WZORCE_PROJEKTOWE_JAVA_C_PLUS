package chain;

public class CEO extends Approver {
    public void approveRequest(Document doc) {
        System.out.println("CEO zatwierdził dostęp do dokumentu: " + doc.getTitle());
    }
}
