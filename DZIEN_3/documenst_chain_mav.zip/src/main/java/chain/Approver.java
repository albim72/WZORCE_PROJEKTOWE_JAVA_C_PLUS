package chain;

public abstract class Approver {
    protected Approver nextApprover;

    public void setNextApprover(Approver next) {
        this.nextApprover = next;
    }

    public abstract void approveRequest(Document document);
}
