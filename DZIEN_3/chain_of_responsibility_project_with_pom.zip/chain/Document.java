package chain;

public class Document {
    private String title;
    private int sensitivityLevel;

    public Document(String title, int sensitivityLevel) {
        this.title = title;
        this.sensitivityLevel = sensitivityLevel;
    }

    public String getTitle() {
        return title;
    }

    public int getSensitivityLevel() {
        return sensitivityLevel;
    }
}
