package chain;

public class TeamLeader extends Approver {
    public void approveRequest(Document doc) {
        if (doc.getSensitivityLevel() <= 1) {
            System.out.println("Team Leader zatwierdził dostęp do dokumentu: " + doc.getTitle());
        } else if (nextApprover != null) {
            nextApprover.approveRequest(doc);
        }
    }
}
