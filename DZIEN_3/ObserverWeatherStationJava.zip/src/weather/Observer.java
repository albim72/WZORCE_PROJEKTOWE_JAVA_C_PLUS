package weather;

public interface Observer {
    void update(String weather);
}