package main;

import weather.WeatherStation;
import app.WeatherApp;
import app.SportsApp;
import app.NewsPortal;

public class Main {
    public static void main(String[] args) {
        WeatherStation station = new WeatherStation();

        WeatherApp weatherApp = new WeatherApp("Meteo24");
        SportsApp sportsApp = new SportsApp();
        NewsPortal newsPortal = new NewsPortal();

        station.addObserver(weatherApp);
        station.addObserver(sportsApp);
        station.addObserver(newsPortal);

        station.setWeather("Słonecznie, 25°C");
        station.setWeather("Silny wiatr, 14°C");
        station.setWeather("Intensywny deszcz, 10°C");
    }
}