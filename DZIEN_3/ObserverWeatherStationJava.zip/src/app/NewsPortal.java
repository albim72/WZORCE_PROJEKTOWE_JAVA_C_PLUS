package app;

import weather.Observer;

public class NewsPortal implements Observer {
    @Override
    public void update(String weather) {
        System.out.println("[NewsPortal] Wiadomość pogodowa: " + weather);
    }
}