package app;

import weather.Observer;

public class WeatherApp implements Observer {
    private String name;

    public WeatherApp(String name) {
        this.name = name;
    }

    @Override
    public void update(String weather) {
        System.out.println("[WeatherApp - " + name + "] Aktualizacja pogody: " + weather);
    }
}