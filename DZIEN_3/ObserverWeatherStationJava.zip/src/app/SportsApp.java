package app;

import weather.Observer;

public class SportsApp implements Observer {
    @Override
    public void update(String weather) {
        if (weather.contains("deszcz")) {
            System.out.println("[SportsApp] Uwaga! Możliwe odwołanie wydarzeń sportowych: " + weather);
        } else {
            System.out.println("[SportsApp] Warunki na sport: " + weather);
        }
    }
}