#ifndef TRAFFICLIGHT_H
#define TRAFFICLIGHT_H

#include "../state/State.h"

class TrafficLight {
private:
    State* state;
public:
    TrafficLight() : state(nullptr) {}
    void setState(State* s) {
        state = s;
    }
    void change() {
        if (state) state->handle();
        else std::cout << "No state is set." << std::endl;
    }
};

#endif // TRAFFICLIGHT_H
