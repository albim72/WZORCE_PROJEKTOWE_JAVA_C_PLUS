#ifndef REDLIGHT_H
#define REDLIGHT_H

#include "State.h"
#include <iostream>

class RedLight : public State {
public:
    void handle() override {
        std::cout << "Red Light - Cars must stop." << std::endl;
    }
};

#endif // REDLIGHT_H
