#ifndef STATE_H
#define STATE_H

class State {
public:
    virtual ~State() = default;
    virtual void handle() = 0;
};

#endif // STATE_H
