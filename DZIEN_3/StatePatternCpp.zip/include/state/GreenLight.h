#ifndef GREENLIGHT_H
#define GREENLIGHT_H

#include "State.h"
#include <iostream>

class GreenLight : public State {
public:
    void handle() override {
        std::cout << "Green Light - Cars can go." << std::endl;
    }
};

#endif // GREENLIGHT_H
