#ifndef YELLOWLIGHT_H
#define YELLOWLIGHT_H

#include "State.h"
#include <iostream>

class YellowLight : public State {
public:
    void handle() override {
        std::cout << "Yellow Light - Prepare to stop." << std::endl;
    }
};

#endif // YELLOWLIGHT_H
