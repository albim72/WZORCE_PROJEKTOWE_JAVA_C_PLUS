#include "../include/context/TrafficLight.h"
#include "../include/state/GreenLight.h"
#include "../include/state/YellowLight.h"
#include "../include/state/RedLight.h"

int main() {
    TrafficLight light;

    GreenLight green;
    YellowLight yellow;
    RedLight red;

    light.setState(&green);
    light.change();

    light.setState(&yellow);
    light.change();

    light.setState(&red);
    light.change();

    return 0;
}
