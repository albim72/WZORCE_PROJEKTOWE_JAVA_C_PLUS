package coffee;

public class CoffeeMachine {
    private CoffeeStrategy strategy;

    public void setStrategy(CoffeeStrategy strategy) {
        this.strategy = strategy;
    }

    public void makeCoffee() {
        if (strategy != null) {
            strategy.prepare();
        } else {
            System.out.println("No coffee strategy set.");
        }
    }
}
