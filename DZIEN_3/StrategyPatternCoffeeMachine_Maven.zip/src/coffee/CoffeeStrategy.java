package coffee;

public interface CoffeeStrategy {
    void prepare();
}
