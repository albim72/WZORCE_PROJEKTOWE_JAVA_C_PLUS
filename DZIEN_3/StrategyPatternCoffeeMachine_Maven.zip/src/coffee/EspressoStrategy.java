package coffee;

public class EspressoStrategy implements CoffeeStrategy {
    public void prepare() {
        System.out.println("Preparing a strong espresso...");
    }
}
