package coffee;

public class Main {
    public static void main(String[] args) {
        CoffeeMachine machine = new CoffeeMachine();

        System.out.println("Client selects Espresso:");
        machine.setStrategy(new EspressoStrategy());
        machine.makeCoffee();

        System.out.println("\nClient selects Latte:");
        machine.setStrategy(new LatteStrategy());
        machine.makeCoffee();

        System.out.println("\nClient selects Cappuccino:");
        machine.setStrategy(new CappuccinoStrategy());
        machine.makeCoffee();
    }
}
