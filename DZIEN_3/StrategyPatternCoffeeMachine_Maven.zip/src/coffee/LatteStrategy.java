package coffee;

public class LatteStrategy implements CoffeeStrategy {
    public void prepare() {
        System.out.println("Steaming milk...");
        System.out.println("Adding milk to espresso for a latte.");
    }
}
