package coffee;

public class CappuccinoStrategy implements CoffeeStrategy {
    public void prepare() {
        System.out.println("Frothing milk...");
        System.out.println("Making a cappuccino with milk foam.");
    }
}
