#include <iostream>
#include <string>
#include <memory>

class Document {
public:
    Document(const std::string& title, int sensitivity)
        : title(title), sensitivityLevel(sensitivity) {}

    std::string getTitle() const { return title; }
    int getSensitivityLevel() const { return sensitivityLevel; }

private:
    std::string title;
    int sensitivityLevel;
};

class Approver {
public:
    virtual ~Approver() = default;
    void setNext(std::shared_ptr<Approver> next) { nextApprover = next; }

    virtual void approve(const Document& doc) {
        if (nextApprover) {
            nextApprover->approve(doc);
        }
    }

protected:
    std::shared_ptr<Approver> nextApprover;
};

class TeamLeader : public Approver {
public:
    void approve(const Document& doc) override {
        if (doc.getSensitivityLevel() <= 1) {
            std::cout << "Team Leader zatwierdził dostęp do dokumentu: " << doc.getTitle() << std::endl;
        } else if (nextApprover) {
            nextApprover->approve(doc);
        }
    }
};

class DepartmentManager : public Approver {
public:
    void approve(const Document& doc) override {
        if (doc.getSensitivityLevel() <= 2) {
            std::cout << "Kierownik Działu zatwierdził dostęp do dokumentu: " << doc.getTitle() << std::endl;
        } else if (nextApprover) {
            nextApprover->approve(doc);
        }
    }
};

class CEO : public Approver {
public:
    void approve(const Document& doc) override {
        std::cout << "CEO zatwierdził dostęp do dokumentu: " << doc.getTitle() << std::endl;
    }
};

int main() {
    auto teamLeader = std::make_shared<TeamLeader>();
    auto departmentManager = std::make_shared<DepartmentManager>();
    auto ceo = std::make_shared<CEO>();

    teamLeader->setNext(departmentManager);
    departmentManager->setNext(ceo);

    Document doc1("Plan Szkolenia", 1);
    Document doc2("Budżet Projektu", 2);
    Document doc3("Fuzja Firm", 3);

    teamLeader->approve(doc1);
    teamLeader->approve(doc2);
    teamLeader->approve(doc3);

    return 0;
}
