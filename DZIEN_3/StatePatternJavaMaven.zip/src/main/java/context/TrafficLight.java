package context;

import state.State;

public class TrafficLight {
    private State state;

    public void setState(State state) {
        this.state = state;
    }

    public void change() {
        if (state != null) {
            state.handle();
        } else {
            System.out.println("No state is set.");
        }
    }
}
