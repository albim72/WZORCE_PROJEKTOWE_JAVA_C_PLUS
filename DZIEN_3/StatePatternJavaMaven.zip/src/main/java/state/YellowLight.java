package state;

public class YellowLight implements State {
    @Override
    public void handle() {
        System.out.println("Yellow Light - Prepare to stop.");
    }
}
