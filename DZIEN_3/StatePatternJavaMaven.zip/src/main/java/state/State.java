package state;

public interface State {
    void handle();
}
