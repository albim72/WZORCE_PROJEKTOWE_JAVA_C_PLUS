package state;

public class RedLight implements State {
    @Override
    public void handle() {
        System.out.println("Red Light - Cars must stop.");
    }
}
