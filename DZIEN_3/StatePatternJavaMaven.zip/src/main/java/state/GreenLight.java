package state;

public class GreenLight implements State {
    @Override
    public void handle() {
        System.out.println("Green Light - Cars can go.");
    }
}
