import context.TrafficLight;
import state.GreenLight;
import state.YellowLight;
import state.RedLight;

public class Main {
    public static void main(String[] args) {
        TrafficLight light = new TrafficLight();

        light.setState(new GreenLight());
        light.change();

        light.setState(new YellowLight());
        light.change();

        light.setState(new RedLight());
        light.change();
    }
}
