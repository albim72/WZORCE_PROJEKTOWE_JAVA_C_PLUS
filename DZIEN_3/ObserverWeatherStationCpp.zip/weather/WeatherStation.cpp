#include "WeatherStation.hpp"
#include <algorithm>

void WeatherStation::setWeather(const std::string& newWeather) {
    weather = newWeather;
    notifyObservers();
}

void WeatherStation::addObserver(Observer* o) {
    observers.push_back(o);
}

void WeatherStation::removeObserver(Observer* o) {
    observers.erase(std::remove(observers.begin(), observers.end(), o), observers.end());
}

void WeatherStation::notifyObservers() {
    for (auto* o : observers) {
        o->update(weather);
    }
}