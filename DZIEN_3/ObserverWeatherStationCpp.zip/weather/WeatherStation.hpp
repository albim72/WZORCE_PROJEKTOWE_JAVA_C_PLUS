#ifndef WEATHERSTATION_HPP
#define WEATHERSTATION_HPP
#include "Subject.hpp"
#include <vector>
#include <string>

class WeatherStation : public Subject {
    std::vector<Observer*> observers;
    std::string weather;
public:
    void setWeather(const std::string& newWeather);
    void addObserver(Observer* o) override;
    void removeObserver(Observer* o) override;
    void notifyObservers() override;
};

#endif