#ifndef WEATHERAPP_HPP
#define WEATHERAPP_HPP
#include "../weather/Observer.hpp"
#include <string>

class WeatherApp : public Observer {
    std::string name;
public:
    WeatherApp(const std::string& name_);
    void update(const std::string& weather) override;
};

#endif