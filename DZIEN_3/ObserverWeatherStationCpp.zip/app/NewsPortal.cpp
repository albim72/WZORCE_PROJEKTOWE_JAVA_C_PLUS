#include "NewsPortal.hpp"
#include <iostream>

void NewsPortal::update(const std::string& weather) {
    std::cout << "[NewsPortal] Wiadomość pogodowa: " << weather << std::endl;
}