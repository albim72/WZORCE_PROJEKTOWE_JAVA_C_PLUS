#include "SportsApp.hpp"
#include <iostream>

void SportsApp::update(const std::string& weather) {
    if (weather.find("deszcz") != std::string::npos) {
        std::cout << "[SportsApp] Uwaga! Możliwe odwołanie wydarzeń sportowych: " << weather << std::endl;
    } else {
        std::cout << "[SportsApp] Warunki na sport: " << weather << std::endl;
    }
}