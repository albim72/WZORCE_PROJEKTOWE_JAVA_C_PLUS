#ifndef NEWSPORTAL_HPP
#define NEWSPORTAL_HPP
#include "../weather/Observer.hpp"
#include <string>

class NewsPortal : public Observer {
public:
    void update(const std::string& weather) override;
};

#endif