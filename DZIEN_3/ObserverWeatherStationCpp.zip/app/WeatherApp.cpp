#include "WeatherApp.hpp"
#include <iostream>

WeatherApp::WeatherApp(const std::string& name_) : name(name_) {}

void WeatherApp::update(const std::string& weather) {
    std::cout << "[WeatherApp - " << name << "] Aktualizacja pogody: " << weather << std::endl;
}