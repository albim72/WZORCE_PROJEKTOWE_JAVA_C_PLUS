#ifndef SPORTSAPP_HPP
#define SPORTSAPP_HPP
#include "../weather/Observer.hpp"
#include <string>

class SportsApp : public Observer {
public:
    void update(const std::string& weather) override;
};

#endif