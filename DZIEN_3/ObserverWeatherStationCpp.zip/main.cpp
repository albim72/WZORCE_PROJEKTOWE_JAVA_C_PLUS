#include "weather/WeatherStation.hpp"
#include "app/WeatherApp.hpp"
#include "app/SportsApp.hpp"
#include "app/NewsPortal.hpp"

int main() {
    WeatherStation station;

    WeatherApp weatherApp("Meteo24");
    SportsApp sportsApp;
    NewsPortal newsPortal;

    station.addObserver(&weatherApp);
    station.addObserver(&sportsApp);
    station.addObserver(&newsPortal);

    station.setWeather("Słonecznie, 25°C");
    station.setWeather("Silny wiatr, 14°C");
    station.setWeather("Intensywny deszcz, 10°C");

    return 0;
}