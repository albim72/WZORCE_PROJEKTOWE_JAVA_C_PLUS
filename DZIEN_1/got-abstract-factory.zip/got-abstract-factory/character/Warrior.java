package character;

public interface Warrior {
    void attack();
}