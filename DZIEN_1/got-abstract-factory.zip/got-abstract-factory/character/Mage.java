package character;

public interface Mage {
    void castSpell();
}