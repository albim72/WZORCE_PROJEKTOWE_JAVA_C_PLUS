package stark;

import character.Mage;
import character.Warrior;
import factory.CharacterFactory;

public class StarkFactory implements CharacterFactory {
    @Override
    public Warrior createWarrior() {
        return new StarkWarrior();
    }

    @Override
    public Mage createMage() {
        return new StarkMage();
    }
}