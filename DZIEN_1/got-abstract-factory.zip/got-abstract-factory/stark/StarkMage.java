package stark;

import character.Mage;

public class StarkMage implements Mage {
    @Override
    public void castSpell() {
        System.out.println("Stark Mage casts a spell of winter and justice!");
    }
}