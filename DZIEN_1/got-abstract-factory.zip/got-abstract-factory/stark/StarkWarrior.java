package stark;

import character.Warrior;

public class StarkWarrior implements Warrior {
    @Override
    public void attack() {
        System.out.println("Stark Warrior swings a greatsword with honor!");
    }
}