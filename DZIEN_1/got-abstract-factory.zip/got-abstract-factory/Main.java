import character.Mage;
import character.Warrior;
import factory.CharacterFactory;
import stark.StarkFactory;
import lannister.LannisterFactory;

public class Main {
    public static void main(String[] args) {
        CharacterFactory starkFactory = new StarkFactory();
        Warrior starkWarrior = starkFactory.createWarrior();
        Mage starkMage = starkFactory.createMage();

        CharacterFactory lannisterFactory = new LannisterFactory();
        Warrior lannisterWarrior = lannisterFactory.createWarrior();
        Mage lannisterMage = lannisterFactory.createMage();

        System.out.println("=== Stark Characters ===");
        starkWarrior.attack();
        starkMage.castSpell();

        System.out.println("\n=== Lannister Characters ===");
        lannisterWarrior.attack();
        lannisterMage.castSpell();
    }
}