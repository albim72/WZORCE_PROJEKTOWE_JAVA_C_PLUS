package factory;

import character.Mage;
import character.Warrior;

public interface CharacterFactory {
    Warrior createWarrior();
    Mage createMage();
}