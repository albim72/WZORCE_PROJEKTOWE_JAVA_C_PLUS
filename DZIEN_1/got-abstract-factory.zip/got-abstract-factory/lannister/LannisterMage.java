package lannister;

import character.Mage;

public class LannisterMage implements Mage {
    @Override
    public void castSpell() {
        System.out.println("Lannister Mage casts a fire spell full of ambition!");
    }
}