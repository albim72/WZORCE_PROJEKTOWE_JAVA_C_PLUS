package lannister;

import character.Warrior;

public class LannisterWarrior implements Warrior {
    @Override
    public void attack() {
        System.out.println("Lannister Warrior strikes with a golden longsword!");
    }
}