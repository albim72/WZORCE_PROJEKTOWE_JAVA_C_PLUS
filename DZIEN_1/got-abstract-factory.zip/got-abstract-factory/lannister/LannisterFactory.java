package lannister;

import character.Mage;
import character.Warrior;
import factory.CharacterFactory;

public class LannisterFactory implements CharacterFactory {
    @Override
    public Warrior createWarrior() {
        return new LannisterWarrior();
    }

    @Override
    public Mage createMage() {
        return new LannisterMage();
    }
}