class GameWorldBuilder {
    private KingdomFactory factory;

    public GameWorldBuilder(KingdomFactory factory) {
        this.factory = factory;
    }

    public GameWorld buildWorld() {
        GameWorld world = new GameWorld();
        world.setCastle(factory.createCastle());
        world.setHero(factory.createHero());
        return world;
    }
}
