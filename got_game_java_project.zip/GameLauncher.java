public class GameLauncher {
    public static void main(String[] args) {
        KingdomFactory factory = new StarkFactory(); // Można zmienić na LannisterFactory
        GameWorldBuilder builder = new GameWorldBuilder(factory);
        GameWorld game = builder.buildWorld();

        System.out.println("=== Świat gry ===");
        game.displayWorld();
    }
}
