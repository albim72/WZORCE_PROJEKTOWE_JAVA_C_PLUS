interface Castle {
    String getDescription();
}
