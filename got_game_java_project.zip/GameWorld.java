class GameWorld {
    private Castle castle;
    private Hero hero;

    public void setCastle(Castle castle) {
        this.castle = castle;
    }

    public void setHero(Hero hero) {
        this.hero = hero;
    }

    public void displayWorld() {
        System.out.println("Zamek: " + castle.getDescription());
        System.out.println("Bohater: " + hero.getName() + ", Broń: " + hero.getWeapon());
    }
}
