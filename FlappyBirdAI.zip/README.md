# Flappy Bird AI Trainer

Interaktywna aplikacja Java łącząca sieci neuronowe i algorytmy genetyczne z wizualizacją w JavaFX.

## Opis projektu

Celem projektu jest wytrenowanie wirtualnych agentów (ptaków) do gry w stylu Flappy Bird za pomocą algorytmu genetycznego, który optymalizuje wagi sieci neuronowej sterującej każdym ptakiem. Aplikacja umożliwia obserwowanie ewolucji agentów w czasie rzeczywistym oraz eksperymentowanie z różnymi parametrami algorytmu.

## Wykorzystane technologie i wzorce projektowe

- **Java 11+**
- **JavaFX** – interfejs graficzny i animacje
- **Sieć neuronowa** – wielowarstwowy perceptron (MLP)
- **Algorytm genetyczny** – selekcja turniejowa, krzyżowanie jednolite, mutacja Gaussa
- **Wzorce projektowe:**
  - **Builder** i **Factory** – tworzenie domyślnej i konfigurowalnej sieci neuronowej
  - **Strategy** – podmienialne strategie selekcji, krzyżowania i mutacji
  - **Observer** – powiadamianie panelu UI o postępie generacji
  - **Command** – przyciski Start/Pauza/Reset w panelu sterowania

## Architektura projektu

```
neuroga.flappy
├── src
│   └── main
│       ├── java
│       │   └── neuroga
│       │       ├── flappy
│       │       │   ├── core
│       │       │   │   ├── Bird.java
│       │       │   │   ├── Pipe.java
│       │       │   │   ├── GeneticTrainer.java
│       │       │   │   ├── NeuralNetwork.java
│       │       │   │   ├── GeneticAlgorithm.java
│       │       │   │   ├── Individual.java
│       │       │   │   ├── SelectionStrategy.java
│       │       │   │   ├── CrossoverStrategy.java
│       │       │   │   ├── MutationStrategy.java
│       │       │   │   ├── Observer.java
│       │       │   │   ├── NeuralNetworkBuilder.java
│       │       │   │   └── NeuralNetworkFactory.java
│       │       │   ├── GameController.java
│       │       │   └── ui
│       │       │       ├── Main.java
│       │       │       ├── ControlPanel.java
│       │       │       └── FitnessChart.java
└── pom.xml
```

## Instrukcja uruchomienia

1. Sklonuj repozytorium lub rozpakuj archiwum.
2. Przejdź do katalogu głównego projektu.
3. Uruchom:
   ```bash
   mvn clean javafx:run
   ```
