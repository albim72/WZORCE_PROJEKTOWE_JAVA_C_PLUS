public class GameFacade {
    private KingdomFactory factory;
    private GameWorldBuilder builder;

    public GameFacade(KingdomFactory factory) {
        this.factory = factory;
        this.builder = new GameWorldBuilder(factory);
    }

    public GameWorld createGameWorld() {
        return builder.buildWorld();
    }
}
