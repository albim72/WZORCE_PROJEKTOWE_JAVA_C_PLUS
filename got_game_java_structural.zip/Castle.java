public interface Castle {
    String getDescription();
}
