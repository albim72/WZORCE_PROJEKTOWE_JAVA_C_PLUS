public class StarkHero implements Hero {
    public String getName() {
        return "Jon Snow";
    }
    public String getWeapon() {
        return "Longclaw (Valyrian steel sword)";
    }
}
