public interface KingdomFactory {
    Castle createCastle();
    Hero createHero();
}
