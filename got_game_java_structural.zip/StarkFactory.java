public class StarkFactory implements KingdomFactory {
    public Castle createCastle() {
        return new StarkCastle();
    }
    public Hero createHero() {
        return new StarkHero();
    }
}
