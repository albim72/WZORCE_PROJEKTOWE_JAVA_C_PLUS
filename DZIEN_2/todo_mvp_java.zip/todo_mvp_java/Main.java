import model.TaskRepository;
import presenter.TaskPresenter;
import view.TaskView;
import model.Task;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        TaskRepository repository = new TaskRepository();
        TaskView view = new ConsoleTaskView();
        TaskPresenter presenter = new TaskPresenter(repository, view);
        presenter.run();
    }

    static class ConsoleTaskView implements TaskView {
        Scanner scanner = new Scanner(System.in);

        public void showTasks(List<Task> tasks) {
            for (int i = 0; i < tasks.size(); i++) {
                System.out.println("[" + i + "] " + tasks.get(i));
            }
        }

        public void showMessage(String message) {
            System.out.println(message);
        }

        public String prompt() {
            System.out.print("> ");
            return scanner.nextLine();
        }
    }
}