package view;

import model.Task;

import java.util.List;

public interface TaskView {
    void showTasks(List<Task> tasks);
    void showMessage(String message);
    String prompt();
}