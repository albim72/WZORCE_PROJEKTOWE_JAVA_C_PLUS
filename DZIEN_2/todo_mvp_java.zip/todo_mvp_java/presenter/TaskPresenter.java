package presenter;

import model.Task;
import model.TaskRepository;
import view.TaskView;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class TaskPresenter {
    private TaskRepository repository;
    private TaskView view;
    private Scanner scanner = new Scanner(System.in);

    public TaskPresenter(TaskRepository repository, TaskView view) {
        this.repository = repository;
        this.view = view;
    }

    public void run() {
        while (true) {
            String input = view.prompt();
            String[] parts = input.trim().split(" ", 2);
            String command = parts[0].toLowerCase();

            switch (command) {
                case "add":
                    if (parts.length > 1) {
                        repository.addTask(parts[1]);
                        view.showMessage("Task added.");
                    } else {
                        view.showMessage("Missing task title.");
                    }
                    break;
                case "done":
                    if (parts.length > 1) {
                        int index = Integer.parseInt(parts[1]);
                        repository.setTaskCompleted(index, true);
                        view.showMessage("Task marked as done.");
                    } else {
                        view.showMessage("Missing task index.");
                    }
                    break;
                case "list":
                    if (parts.length > 1) {
                        showTasks(parts[1]);
                    } else {
                        showTasks("all");
                    }
                    break;
                case "exit":
                    view.showMessage("Exiting...");
                    return;
                default:
                    view.showMessage("Unknown command.");
            }
        }
    }

    private void showTasks(String filter) {
        List<Task> allTasks = repository.getTasks();
        List<Task> filtered;

        switch (filter.toLowerCase()) {
            case "completed":
                filtered = allTasks.stream().filter(Task::isCompleted).collect(Collectors.toList());
                break;
            case "pending":
                filtered = allTasks.stream().filter(t -> !t.isCompleted()).collect(Collectors.toList());
                break;
            default:
                filtered = allTasks;
        }

        for (int i = 0; i < filtered.size(); i++) {
            view.showMessage("[" + i + "] " + filtered.get(i));
        }
    }
}