#ifndef CUSTOMERADAPTER_H
#define CUSTOMERADAPTER_H

#include "CustomerJSON.h"
#include "CustomerCSV.h"
#include <sstream>
#include <vector>

class CustomerAdapter : public CustomerJSON {
private:
    CustomerCSV customerCSV;

    std::vector<std::string> splitCSV() const {
        std::vector<std::string> result;
        std::stringstream ss(customerCSV.getCSV());
        std::string item;
        while (getline(ss, item, ',')) {
            result.push_back(item);
        }
        return result;
    }

public:
    CustomerAdapter(const CustomerCSV& csv) : customerCSV(csv) {}

    std::string getFullName() const override {
        auto data = splitCSV();
        return data[0] + " " + data[1];
    }

    std::string getEmail() const override {
        return splitCSV()[2];
    }

    std::string getPhoneNumber() const override {
        return splitCSV()[3];
    }
};

#endif
