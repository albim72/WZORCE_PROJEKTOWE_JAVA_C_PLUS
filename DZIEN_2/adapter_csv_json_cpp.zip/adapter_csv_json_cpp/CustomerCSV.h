#ifndef CUSTOMERCSV_H
#define CUSTOMERCSV_H

#include <string>

class CustomerCSV {
private:
    std::string csvLine;

public:
    CustomerCSV(const std::string& line) : csvLine(line) {}
    std::string getCSV() const { return csvLine; }
};

#endif
