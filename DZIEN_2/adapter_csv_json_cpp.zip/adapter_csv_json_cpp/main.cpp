#include <iostream>
#include <string>
#include "CustomerJSON.h"
#include "CustomerCSV.h"
#include "CustomerAdapter.h"

int main() {
    CustomerCSV oldCustomer("John,Smith,john.smith@example.com,+48 123 456 789");
    CustomerJSON* adaptedCustomer = new CustomerAdapter(oldCustomer);

    std::cout << "Full name: " << adaptedCustomer->getFullName() << std::endl;
    std::cout << "Email: " << adaptedCustomer->getEmail() << std::endl;
    std::cout << "Phone: " << adaptedCustomer->getPhoneNumber() << std::endl;

    delete adaptedCustomer;
    return 0;
}
