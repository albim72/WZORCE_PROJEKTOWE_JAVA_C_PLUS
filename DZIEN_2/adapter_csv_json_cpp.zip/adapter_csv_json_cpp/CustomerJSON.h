#ifndef CUSTOMERJSON_H
#define CUSTOMERJSON_H

#include <string>

class CustomerJSON {
public:
    virtual std::string getFullName() const = 0;
    virtual std::string getEmail() const = 0;
    virtual std::string getPhoneNumber() const = 0;
    virtual ~CustomerJSON() = default;
};

#endif
