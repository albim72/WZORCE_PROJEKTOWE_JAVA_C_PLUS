#ifndef HOTELBOOKING_H
#define HOTELBOOKING_H

#include <iostream>
#include <string>

class HotelBooking {
public:
    void bookHotel(const std::string& city) {
        std::cout << "Hotel zarezerwowany w: " << city << std::endl;
    }
};

#endif
