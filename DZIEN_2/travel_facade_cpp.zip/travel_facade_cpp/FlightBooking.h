#ifndef FLIGHTBOOKING_H
#define FLIGHTBOOKING_H

#include <iostream>
#include <string>

class FlightBooking {
public:
    void bookFlight(const std::string& destination) {
        std::cout << "Lot zarezerwowany do: " << destination << std::endl;
    }
};

#endif
