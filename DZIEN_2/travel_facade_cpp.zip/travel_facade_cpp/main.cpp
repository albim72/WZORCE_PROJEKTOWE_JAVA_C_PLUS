#include <iostream>
#include "TravelFacade.h"

int main() {
    TravelFacade travel;
    travel.bookTrip("Paryż", "Paryż", "Lotnisko Chopina");
    return 0;
}
