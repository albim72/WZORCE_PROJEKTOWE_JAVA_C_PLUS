#ifndef TAXIBOOKING_H
#define TAXIBOOKING_H

#include <iostream>
#include <string>

class TaxiBooking {
public:
    void bookTaxi(const std::string& address) {
        std::cout << "Taksówka zamówiona na adres: " << address << std::endl;
    }
};

#endif
