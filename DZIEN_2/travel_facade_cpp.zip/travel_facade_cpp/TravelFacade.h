#ifndef TRAVELFACADE_H
#define TRAVELFACADE_H

#include "FlightBooking.h"
#include "HotelBooking.h"
#include "TaxiBooking.h"

class TravelFacade {
private:
    FlightBooking flight;
    HotelBooking hotel;
    TaxiBooking taxi;

public:
    void bookTrip(const std::string& destination, const std::string& hotelCity, const std::string& taxiAddress) {
        flight.bookFlight(destination);
        hotel.bookHotel(hotelCity);
        taxi.bookTaxi(taxiAddress);
        std::cout << "Cała podróż została zarezerwowana!" << std::endl;
    }
};

#endif
