#ifndef WEATHER_VIEW_H
#define WEATHER_VIEW_H

#include <string>

class WeatherView {
public:
    virtual void showWeather(const std::string& city, const std::string& weather) = 0;
    virtual std::string promptForCity() = 0;
    virtual ~WeatherView() {}
};

#endif