#include "ConsoleWeatherView.h"

void ConsoleWeatherView::showWeather(const std::string& city, const std::string& weather) {
    std::cout << "Pogoda w " << city << ": " << weather << std::endl;
}

std::string ConsoleWeatherView::promptForCity() {
    std::cout << "Podaj miasto: ";
    std::string city;
    std::getline(std::cin, city);
    return city;
}