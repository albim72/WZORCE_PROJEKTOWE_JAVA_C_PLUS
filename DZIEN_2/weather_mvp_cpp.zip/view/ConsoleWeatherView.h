#ifndef CONSOLE_WEATHER_VIEW_H
#define CONSOLE_WEATHER_VIEW_H

#include "WeatherView.h"
#include <iostream>

class ConsoleWeatherView : public WeatherView {
public:
    void showWeather(const std::string& city, const std::string& weather) override;
    std::string promptForCity() override;
};

#endif