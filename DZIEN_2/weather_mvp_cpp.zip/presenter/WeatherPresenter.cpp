#include "WeatherPresenter.h"

WeatherPresenter::WeatherPresenter(WeatherModel* model, WeatherView* view)
    : model(model), view(view) {}

void WeatherPresenter::start() {
    std::string city = view->promptForCity();
    std::string weather = model->getWeatherForCity(city);
    view->showWeather(city, weather);
}