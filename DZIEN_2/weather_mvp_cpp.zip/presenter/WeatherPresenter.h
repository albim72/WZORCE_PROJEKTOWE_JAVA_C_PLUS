#ifndef WEATHER_PRESENTER_H
#define WEATHER_PRESENTER_H

#include "../model/WeatherModel.h"
#include "../view/WeatherView.h"

class WeatherPresenter {
public:
    WeatherPresenter(WeatherModel* model, WeatherView* view);
    void start();
private:
    WeatherModel* model;
    WeatherView* view;
};

#endif