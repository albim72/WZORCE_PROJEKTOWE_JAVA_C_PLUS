#include "model/WeatherModel.h"
#include "view/ConsoleWeatherView.h"
#include "presenter/WeatherPresenter.h"

int main() {
    WeatherModel model;
    ConsoleWeatherView view;
    WeatherPresenter presenter(&model, &view);
    presenter.start();
    return 0;
}