#ifndef WEATHER_MODEL_H
#define WEATHER_MODEL_H

#include <string>
#include <unordered_map>

class WeatherModel {
public:
    WeatherModel();
    std::string getWeatherForCity(const std::string& city) const;
private:
    std::unordered_map<std::string, std::string> weatherData;
};

#endif