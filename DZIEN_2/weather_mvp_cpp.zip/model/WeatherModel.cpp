#include "WeatherModel.h"

WeatherModel::WeatherModel() {
    weatherData["Warszawa"] = "Słonecznie, 25°C";
    weatherData["Kraków"] = "Pochmurno, 20°C";
    weatherData["Gdańsk"] = "Deszcz, 18°C";
}

std::string WeatherModel::getWeatherForCity(const std::string& city) const {
    auto it = weatherData.find(city);
    if (it != weatherData.end()) {
        return it->second;
    }
    return "Brak danych pogodowych";
}