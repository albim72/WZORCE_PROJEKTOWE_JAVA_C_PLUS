#include "model/TaskRepository.h"
#include "presenter/TaskPresenter.h"
#include "view/TaskView.h"

#include <iostream>

class ConsoleTaskView : public TaskView {
public:
    void showTasks(const std::vector<Task>& tasks) override {
        for (size_t i = 0; i < tasks.size(); ++i) {
            std::cout << "[" << i << "] " << tasks[i].toString() << std::endl;
        }
    }

    void showMessage(const std::string& message) override {
        std::cout << message << std::endl;
    }

    std::string prompt() override {
        std::cout << "> ";
        std::string input;
        std::getline(std::cin, input);
        return input;
    }
};

int main() {
    TaskRepository repository;
    ConsoleTaskView view;
    TaskPresenter presenter(repository, view);
    presenter.run();
    return 0;
}