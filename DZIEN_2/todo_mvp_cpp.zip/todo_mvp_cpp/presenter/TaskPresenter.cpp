#include "TaskPresenter.h"
#include <iostream>
#include <sstream>
#include <algorithm>

TaskPresenter::TaskPresenter(TaskRepository& repo, TaskView& vw) : repository(repo), view(vw) {}

void TaskPresenter::run() {
    while (true) {
        std::string input = view.prompt();
        std::istringstream iss(input);
        std::string command;
        iss >> command;

        if (command == "add") {
            std::string title;
            std::getline(iss, title);
            if (!title.empty()) {
                repository.addTask(title.substr(1));
                view.showMessage("Task added.");
            } else {
                view.showMessage("Missing task title.");
            }
        } else if (command == "done") {
            int index;
            if (iss >> index) {
                repository.setTaskCompleted(index, true);
                view.showMessage("Task marked as done.");
            } else {
                view.showMessage("Invalid task index.");
            }
        } else if (command == "list") {
            std::string filter;
            iss >> filter;
            showTasks(filter.empty() ? "all" : filter);
        } else if (command == "exit") {
            view.showMessage("Exiting...");
            break;
        } else {
            view.showMessage("Unknown command.");
        }
    }
}

void TaskPresenter::showTasks(const std::string& filter) {
    auto& tasks = repository.getTasks();
    for (size_t i = 0; i < tasks.size(); ++i) {
        const Task& task = tasks[i];
        if (filter == "completed" && !task.isCompleted()) continue;
        if (filter == "pending" && task.isCompleted()) continue;
        view.showMessage("[" + std::to_string(i) + "] " + task.toString());
    }
}