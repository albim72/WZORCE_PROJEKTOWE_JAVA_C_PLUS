#ifndef TASKPRESENTER_H
#define TASKPRESENTER_H

#include "../model/TaskRepository.h"
#include "../view/TaskView.h"

class TaskPresenter {
private:
    TaskRepository& repository;
    TaskView& view;

public:
    TaskPresenter(TaskRepository& repo, TaskView& vw);
    void run();
    void showTasks(const std::string& filter);
};

#endif