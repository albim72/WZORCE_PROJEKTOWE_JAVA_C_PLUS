#ifndef TASKVIEW_H
#define TASKVIEW_H

#include "../model/Task.h"
#include <vector>
#include <string>

class TaskView {
public:
    virtual void showTasks(const std::vector<Task>& tasks) = 0;
    virtual void showMessage(const std::string& message) = 0;
    virtual std::string prompt() = 0;
    virtual ~TaskView() = default;
};

#endif