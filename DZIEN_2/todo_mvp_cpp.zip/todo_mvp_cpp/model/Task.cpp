#include "Task.h"

Task::Task(const std::string& title) : title(title), completed(false) {}

std::string Task::getTitle() const {
    return title;
}

bool Task::isCompleted() const {
    return completed;
}

void Task::setCompleted(bool status) {
    completed = status;
}

std::string Task::toString() const {
    return title + (completed ? " (done)" : "");
}