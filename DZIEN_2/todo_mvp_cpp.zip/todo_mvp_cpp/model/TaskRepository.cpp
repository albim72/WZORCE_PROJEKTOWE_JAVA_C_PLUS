#include "TaskRepository.h"

void TaskRepository::addTask(const std::string& title) {
    tasks.emplace_back(title);
}

std::vector<Task>& TaskRepository::getTasks() {
    return tasks;
}

void TaskRepository::setTaskCompleted(int index, bool status) {
    if (index >= 0 && index < static_cast<int>(tasks.size())) {
        tasks[index].setCompleted(status);
    }
}