#ifndef TASKREPOSITORY_H
#define TASKREPOSITORY_H

#include "Task.h"
#include <vector>

class TaskRepository {
private:
    std::vector<Task> tasks;

public:
    void addTask(const std::string& title);
    std::vector<Task>& getTasks();
    void setTaskCompleted(int index, bool status);
};

#endif