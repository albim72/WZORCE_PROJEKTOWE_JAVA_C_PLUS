#ifndef TASK_H
#define TASK_H

#include <string>

class Task {
private:
    std::string title;
    bool completed;

public:
    Task(const std::string& title);
    std::string getTitle() const;
    bool isCompleted() const;
    void setCompleted(bool status);
    std::string toString() const;
};

#endif