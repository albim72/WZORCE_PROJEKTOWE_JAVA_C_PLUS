#include "lannister_factory.h"
#include "lannister_warrior.h"
#include "lannister_mage.h"

std::unique_ptr<Warrior> LannisterFactory::createWarrior() {
    return std::make_unique<LannisterWarrior>();
}

std::unique_ptr<Mage> LannisterFactory::createMage() {
    return std::make_unique<LannisterMage>();
}
