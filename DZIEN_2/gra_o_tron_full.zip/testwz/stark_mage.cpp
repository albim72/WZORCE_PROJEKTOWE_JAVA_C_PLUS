#include <iostream>
#include "stark_mage.h"

void StarkMage::castSpell() {
    std::cout << "Stark Mage casts a spell of winter and justice!" << std::endl;
}