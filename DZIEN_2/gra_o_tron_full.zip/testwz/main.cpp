#include <iostream>
#include <memory>
#include "character_factory.h"
#include "stark_factory.h"
#include "lannister_factory.h"

void playWithFactory(std::unique_ptr<CharacterFactory> factory) {
    auto warrior = factory->createWarrior();
    auto mage = factory->createMage();
    warrior->attack();
    mage->castSpell();
}

int main() {
    std::cout << "=== Stark Characters ===\n";
    playWithFactory(std::make_unique<StarkFactory>());

    std::cout << "\n=== Lannister Characters ===\n";
    playWithFactory(std::make_unique<LannisterFactory>());

    return 0;
}