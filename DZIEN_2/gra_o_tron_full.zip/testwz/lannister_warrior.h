#ifndef LANNISTER_WARRIOR_H
#define LANNISTER_WARRIOR_H

#include "warrior.h"

class LannisterWarrior : public Warrior {
public:
    void attack() override;
};

#endif