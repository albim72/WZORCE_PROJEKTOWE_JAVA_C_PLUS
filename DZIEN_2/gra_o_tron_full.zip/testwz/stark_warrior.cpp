#include <iostream>
#include "stark_warrior.h"

void StarkWarrior::attack() {
    std::cout << "Stark Warrior swings a greatsword with honor!" << std::endl;
}