#ifndef MAGE_H
#define MAGE_H

class Mage {
public:
    virtual void castSpell() = 0;
    virtual ~Mage() = default;
};

#endif