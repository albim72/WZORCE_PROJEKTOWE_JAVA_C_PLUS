#ifndef STARK_MAGE_H
#define STARK_MAGE_H

#include "mage.h"

class StarkMage : public Mage {
public:
    void castSpell() override;
};

#endif