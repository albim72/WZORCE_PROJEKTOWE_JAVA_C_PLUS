#ifndef LANNISTER_MAGE_H
#define LANNISTER_MAGE_H

#include "mage.h"

class LannisterMage : public Mage {
public:
    void castSpell() override;
};

#endif