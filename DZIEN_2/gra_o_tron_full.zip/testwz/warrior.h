#ifndef WARRIOR_H
#define WARRIOR_H

class Warrior {
public:
    virtual void attack() = 0;
    virtual ~Warrior() = default;
};

#endif