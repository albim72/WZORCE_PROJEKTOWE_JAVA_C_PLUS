#ifndef CHARACTER_FACTORY_H
#define CHARACTER_FACTORY_H

#include <memory>
#include "warrior.h"
#include "mage.h"

class CharacterFactory {
public:
    virtual std::unique_ptr<Warrior> createWarrior() = 0;
    virtual std::unique_ptr<Mage> createMage() = 0;
    virtual ~CharacterFactory() = default;
};

#endif