#include <iostream>
#include "lannister_warrior.h"

void LannisterWarrior::attack() {
    std::cout << "Lannister Warrior strikes with a golden longsword!" << std::endl;
}