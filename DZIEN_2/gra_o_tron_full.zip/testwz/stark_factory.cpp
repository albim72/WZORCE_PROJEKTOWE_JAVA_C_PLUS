#include "stark_factory.h"
#include "stark_warrior.h"
#include "stark_mage.h"

std::unique_ptr<Warrior> StarkFactory::createWarrior() {
    return std::make_unique<StarkWarrior>();
}

std::unique_ptr<Mage> StarkFactory::createMage() {
    return std::make_unique<StarkMage>();
}
