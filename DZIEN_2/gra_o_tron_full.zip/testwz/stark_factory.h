#ifndef STARK_FACTORY_H
#define STARK_FACTORY_H

#include "character_factory.h"

class StarkFactory : public CharacterFactory {
public:
    std::unique_ptr<Warrior> createWarrior() override;
    std::unique_ptr<Mage> createMage() override;
};

#endif