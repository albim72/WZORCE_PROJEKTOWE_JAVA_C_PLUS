#ifndef STARK_WARRIOR_H
#define STARK_WARRIOR_H

#include "warrior.h"

class StarkWarrior : public Warrior {
public:
    void attack() override;
};

#endif