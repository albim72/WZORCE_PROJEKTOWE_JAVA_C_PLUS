#include <iostream>
#include "lannister_mage.h"

void LannisterMage::castSpell() {
    std::cout << "Lannister Mage casts a fire spell full of ambition!" << std::endl;
}